import { ArtCreateComp } from "~/components/art/ArtCreateComp";
export default function ArtCreate() {
  return <ArtCreateComp />;
}
