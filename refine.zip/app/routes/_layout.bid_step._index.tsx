import { BidStepListComp } from "~/components/bid_step/BidStepListComp";
export default function BidStepList() {
  return <BidStepListComp />;
}
