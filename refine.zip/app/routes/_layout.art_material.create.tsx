import { AntdInferencer } from "@refinedev/inferencer/antd";
import { ArtMaterialCreateComp } from "~/components/art_material/ArtMaterialCreateComp";
export default function ArtMaterialCreate() {
  return <ArtMaterialCreateComp />;
}
