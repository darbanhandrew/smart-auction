import { AuctionHouseShowComp } from "~/components/auction_house/AuctionHouseShowComp";
export default function AuctionHouseShow() {
  return <AuctionHouseShowComp />;
}
