import { AuctionHouseEditComp } from "~/components/auction_house/AuctionHouseEditComp";
export default function AuctionHouseEdit() {
  return <AuctionHouseEditComp />;
}
