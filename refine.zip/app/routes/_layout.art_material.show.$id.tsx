import { AntdInferencer } from "@refinedev/inferencer/antd";
import { ArtMaterialShowComp } from "~/components/art_material/ArtMaterialShowComp";
export default function ArtMaterialShow() {
  return <ArtMaterialShowComp />;
}
