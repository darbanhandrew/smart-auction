import { AntdInferencer } from "@refinedev/inferencer/antd";
import { ArtMaterialListComp } from "~/components/art_material/ArtMaterialListComp";
export default function ArtMaterialList() {
  return <ArtMaterialListComp />;
}
