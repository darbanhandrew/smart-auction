import { ArtListComp } from "~/components/art/ArtListComp";
export default function ArtList() {
  return <ArtListComp />;
}
