import { AuctionArtListComp } from "~/components/auction_art/AuctionArtListComp";
export default function AuctionArtList() {
  return <AuctionArtListComp />;
}
