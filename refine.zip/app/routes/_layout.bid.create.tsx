import { AntdInferencer } from "@refinedev/inferencer/antd";
        export default function BidCreate() {
            return <AntdInferencer />;
        }