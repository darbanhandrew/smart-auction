import { BidStepCategoryCreateComp } from "~/components/bid_step_category/BidStepCategoryCreateComp";
export default function BidStepCategoryCreate() {
  return <BidStepCategoryCreateComp />;
}
