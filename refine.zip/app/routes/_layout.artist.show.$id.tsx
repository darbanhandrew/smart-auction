import { ArtistShowComp } from "~/components/artist/ArtistShowComp";
export default function ArtistShow() {
  return <ArtistShowComp />;
}
