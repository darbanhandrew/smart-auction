import { AuctionCreateComp } from "~/components/auction/AuctionCreateComp";
export default function AuctionCreate() {
  return <AuctionCreateComp />;
}
