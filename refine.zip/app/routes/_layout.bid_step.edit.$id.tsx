import { BidStepEditComp } from "~/components/bid_step/BidStepEditComp";
export default function BidStepEdit() {
  return <BidStepEditComp />;
}
