import { ArtCategoryCreateComp } from "~/components/art_category/ArtCategoryCreateComp";
export default function ArtCategoryCreate() {
  return <ArtCategoryCreateComp />;
}
