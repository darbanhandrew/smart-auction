import { ArtCategoryShowComp } from "~/components/art_category/ArtCategoryShowComp";
export default function ArtCategoryShow() {
  return <ArtCategoryShowComp />;
}
