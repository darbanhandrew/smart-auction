import { BidStepCreateComp } from "~/components/bid_step/BidStepCreateComp";
export default function BidStepCreate() {
  return <BidStepCreateComp />;
}
