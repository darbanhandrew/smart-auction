import { AuctionListComp } from "~/components/auction/AuctionListComp";
export default function AuctionList() {
  return <AuctionListComp />;
}
