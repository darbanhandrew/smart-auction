import { BidStepCategoryListComp } from "~/components/bid_step_category/BidStepCategoryListComp";
export default function BidStepCategoryList() {
  return <BidStepCategoryListComp />;
}
