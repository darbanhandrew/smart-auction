import { ArtTechniqueShowComp } from "~/components/art_technique/ArtTechniqueShowComp";
export default function ArtTechniqueShow() {
  return <ArtTechniqueShowComp />;
}
