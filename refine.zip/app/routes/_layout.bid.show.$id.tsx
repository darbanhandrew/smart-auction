import { AntdInferencer } from "@refinedev/inferencer/antd";
        export default function BidShow() {
            return <AntdInferencer />;
        }