import { BidStepCategoryShowComp } from "~/components/bid_step_category/BidStepCategoryShowComp";
export default function BidStepCategoryShow() {
  return <BidStepCategoryShowComp />;
}
