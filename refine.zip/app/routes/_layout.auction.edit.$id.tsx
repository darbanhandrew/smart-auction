import { AuctionEditComp } from "~/components/auction/AuctionEditComp";
export default function AuctionEdit() {
  return <AuctionEditComp />;
}
