import { ArtEditComp } from "~/components/art/ArtEditComp";
export default function ArtEdit() {
  return <ArtEditComp />;
}
