import { AuctionHouseCreateComp } from "~/components/auction_house/AuctionHouseCreateComp";
export default function AuctionHouseCreate() {
  return <AuctionHouseCreateComp />;
}
