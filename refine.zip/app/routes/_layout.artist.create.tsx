import { ArtistCreateComp } from "~/components/artist/ArtistCreateComp";
export default function ArtistCreate() {
  return <ArtistCreateComp />;
}
