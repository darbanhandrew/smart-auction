import { ArtistEditComp } from "~/components/artist/ArtistEditComp";
export default function ArtistEdit() {
  return <ArtistEditComp />;
}
