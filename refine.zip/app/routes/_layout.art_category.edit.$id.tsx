import { ArtCategoryEditComp } from "~/components/art_category/ArtCategoryEditComp";
export default function ArtCategoryEdit() {
  return <ArtCategoryEditComp />;
}
