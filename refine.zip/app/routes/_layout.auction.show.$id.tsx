import { AntdInferencer } from "@refinedev/inferencer/antd";
        export default function AuctionShow() {
            return <AntdInferencer />;
        }