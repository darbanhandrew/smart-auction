import { AntdInferencer } from "@refinedev/inferencer/antd";
        export default function BidStepShow() {
            return <AntdInferencer />;
        }