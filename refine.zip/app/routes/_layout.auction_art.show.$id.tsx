import { AuctionArtShowComp } from "~/components/auction_art/AuctionArtShowComp";
export default function AuctionArtShow() {
  return <AuctionArtShowComp />;
}
