import { AntdInferencer } from "@refinedev/inferencer/antd";
        export default function BidList() {
            return <AntdInferencer />;
        }