import { ArtTechniqueListComp } from "~/components/art_technique/ArtTechniqueListComp";
export default function ArtTechniqueList() {
  return <ArtTechniqueListComp />;
}
