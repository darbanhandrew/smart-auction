import { AntdInferencer } from "@refinedev/inferencer/antd";
import { ArtTechniqueEditComp } from "~/components/art_technique/ArtTechniqueEditComp";
export default function ArtTechniqueEdit() {
  return <ArtTechniqueEditComp />;
}
