import { ArtMaterialEditComp } from "~/components/art_material/ArtMaterialEditComp";
export default function ArtMaterialEdit() {
  return <ArtMaterialEditComp />;
}
