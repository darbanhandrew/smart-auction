import { ArtShowComp } from "~/components/art/ArtShowComp";

export default function ArtShow() {
  return <ArtShowComp />;
}
