import { AuctionArtCreateComp } from "~/components/auction_art/AuctionArtCreateComp";
export default function AuctionArtCreate() {
  return <AuctionArtCreateComp />;
}
