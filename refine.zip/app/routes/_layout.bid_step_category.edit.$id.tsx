import { BidStepCategoryEditComp } from "~/components/bid_step_category/BidStepCategoryEditComp";
export default function BidStepCategoryEdit() {
  return <BidStepCategoryEditComp />;
}
