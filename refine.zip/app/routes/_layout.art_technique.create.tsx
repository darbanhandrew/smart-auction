import { ArtTechniqueCreateComp } from "~/components/art_technique/ArtTechniqueCreateComp";
export default function ArtTechniqueCreate() {
  return <ArtTechniqueCreateComp />;
}
