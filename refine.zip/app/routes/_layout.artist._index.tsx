import { ArtistListComp } from "~/components/artist/ArtistListComp";
export default function ArtistList() {
  return <ArtistListComp />;
}
