import { ArtCategoryListComp } from "~/components/art_category/ArtCategoryListComp";
export default function ArtCategoryList() {
  return <ArtCategoryListComp />;
}
