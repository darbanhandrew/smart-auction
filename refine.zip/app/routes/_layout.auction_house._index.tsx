import { AuctionHouseListComp } from "~/components/auction_house/AuctionHouseListComp";
export default function AuctionHouseList() {
  return <AuctionHouseListComp />;
}
