import { AuctionArtEditComp } from "~/components/auction_art/AuctionArtEditComp";
export default function AuctionArtEdit() {
  return <AuctionArtEditComp />;
}
