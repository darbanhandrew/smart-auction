import { AntdInferencer } from "@refinedev/inferencer/antd";
        export default function BidEdit() {
            return <AntdInferencer />;
        }