import { AntdInferencer } from "@refinedev/inferencer/antd";
export default function AuctionEdit() {
  return <AntdInferencer />;
}
