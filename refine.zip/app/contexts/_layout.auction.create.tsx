import { AntdInferencer } from "@refinedev/inferencer/antd";
export default function AuctionCreate() {
  return <AntdInferencer />;
}
