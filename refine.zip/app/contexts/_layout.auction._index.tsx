import { AntdInferencer } from "@refinedev/inferencer/antd";
export default function AuctionList() {
  return <AntdInferencer />;
}
