import { Account, Appwrite, Storage } from "@refinedev/appwrite";

const APPWRITE_URL = "https://panel.arthl.ir/v1";
const APPWRITE_PROJECT = "smart-auction";
const TOKEN_KEY = "efc2217a13a147e11fb2227201c355e30960c84a3ba58175687da82bc8700b2030948910ef06cdc13902b6a040761ab86dfee217d38ca5c14239eb4467d8800a79752a448541d68f8b238aa5527cd72cf177b941ce6b43a188655fd644ca3c51255809c92114a98bb8bc788f08215e87e70a5383b3681ac481e579273f999f4e";

const appwriteClient = new Appwrite();

appwriteClient.setEndpoint(APPWRITE_URL).setProject(APPWRITE_PROJECT);
const account = new Account(appwriteClient);
const storage = new Storage(appwriteClient);

export { appwriteClient, account, storage, TOKEN_KEY };
