export default function AuctionShowComp() {
            return <></>;
        }