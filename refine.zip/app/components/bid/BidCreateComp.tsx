export default function BidCreateComp() {
            return <></>;
        }