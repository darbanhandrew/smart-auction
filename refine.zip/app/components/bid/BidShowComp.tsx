export default function BidShowComp() {
            return <></>;
        }