export default function BidEditComp() {
            return <></>;
        }