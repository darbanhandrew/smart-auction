import React from "react";
import { IResourceComponentsProps } from "@refinedev/core";
import { Create, useForm, useSelect } from "@refinedev/antd";
import { Form, Input, DatePicker, Select } from "antd";
import dayjs from "dayjs";

export const ArtCreateComp: React.FC<IResourceComponentsProps> = () => {
  const { formProps, saveButtonProps, queryResult } = useForm();

  const { selectProps: auctionArtSelectProps } = useSelect({
    resource: "auction_art",
    optionLabel: "lot",
    optionValue: "$id",
  });

  const { selectProps: artistSelectProps } = useSelect({
    resource: "artist",
    optionLabel: "name",
    optionValue: "$id",
  });

  const { selectProps: artCategorySelectProps } = useSelect({
    resource: "art_category",
    optionLabel: "name",
    optionValue: "$id",
  });

  const { selectProps: artTechniqueSelectProps } = useSelect({
    resource: "art_technique",
    optionLabel: "name",
    optionValue: "$id",
  });

  const { selectProps: artMaterialSelectProps } = useSelect({
    resource: "art_material",
    optionLabel: "name",
    optionValue: "$id",
  });

  return (
    <Create saveButtonProps={saveButtonProps}>
      <Form {...formProps} layout="vertical">
        <Form.Item
          label="Name"
          name={["name"]}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Size"
          name={["size"]}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Date Of Artwork"
          name={["date_of_artwork"]}
          rules={[
            {
              required: true,
            },
          ]}
          getValueProps={(value) => ({
            value: value ? dayjs(value) : undefined,
          })}
        >
          <DatePicker />
        </Form.Item>
        <Form.Item
          label="$created At"
          name={["$createdAt"]}
          rules={[
            {
              required: true,
            },
          ]}
          getValueProps={(value) => ({
            value: value ? dayjs(value) : undefined,
          })}
        >
          <DatePicker />
        </Form.Item>
        <Form.Item
          label="$updated At"
          name={["$updatedAt"]}
          rules={[
            {
              required: true,
            },
          ]}
          getValueProps={(value) => ({
            value: value ? dayjs(value) : undefined,
          })}
        >
          <DatePicker />
        </Form.Item>
        <Form.Item
          label="Artist"
          name={"artist"}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Select {...artistSelectProps} />
        </Form.Item>
        <Form.Item
          label="Art Material"
          name={"art_material"}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Select {...artMaterialSelectProps} />
        </Form.Item>
        <Form.Item
          label="Art Technique"
          name={"art_technique"}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Select {...artTechniqueSelectProps} />
        </Form.Item>
        <Form.Item
          label="Art Category"
          name={"art_category"}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Select {...artCategorySelectProps} />
        </Form.Item>
        <Form.Item
          label="Auction Art"
          name={"auction_art"}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Select mode="multiple" {...auctionArtSelectProps} />
        </Form.Item>
      </Form>
    </Create>
  );
};
