import React from "react";
import { IResourceComponentsProps } from "@refinedev/core";
import { Edit, useForm, useSelect } from "@refinedev/antd";
import { Form, Input, DatePicker, Select } from "antd";
import dayjs from "dayjs";

export const BidStepEditComp: React.FC<IResourceComponentsProps> = () => {
  const { formProps, saveButtonProps, queryResult } = useForm();

  const bidStepData = queryResult?.data?.data;
  const { selectProps: bidStepCategorySelectProps } = useSelect({
    resource: "bid_step_category",
    optionLabel: "name",
    optionValue: "id",
    defaultValue: queryResult?.data?.data?.bid_step_category.map(
      (item: any) => item.$id
    ),
  });
  return (
    <Edit saveButtonProps={saveButtonProps}>
      <Form {...formProps} layout="vertical">
        <h1>
          <strong>{bidStepData?.id}</strong>
        </h1>
        <Form.Item
          label="Start Price"
          name={["start_price"]}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="End Price"
          name={["end_price"]}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="Step Size"
          name={["step_size"]}
          rules={[
            {
              required: true,
            },
          ]}
        >
          <Input />
        </Form.Item>
        <Form.Item
          label="$created At"
          name={["$createdAt"]}
          rules={[
            {
              required: true,
            },
          ]}
          getValueProps={(value) => ({
            value: value ? dayjs(value) : undefined,
          })}
        >
          <DatePicker />
        </Form.Item>
        <Form.Item
          label="$updated At"
          name={["$updatedAt"]}
          rules={[
            {
              required: true,
            },
          ]}
          getValueProps={(value) => ({
            value: value ? dayjs(value) : undefined,
          })}
        >
          <DatePicker />
        </Form.Item>
        <Form.Item
          label="Bid Step Category"
          name={"bid_step_category"}
          rules={[
            {
              required: true,
            },
          ]}
          getValueProps={(value) =>
            value?.map((item: any) => item) || undefined
          }
          getValueFromEvent={(value) =>
            value?.map((item: any) => item) || undefined
          }
        >
          <Select mode="multiple" {...bidStepCategorySelectProps} />
        </Form.Item>
      </Form>
    </Edit>
  );
};
