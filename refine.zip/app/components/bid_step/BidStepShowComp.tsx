export default function BidStepShowComp() {
            return <></>;
        }